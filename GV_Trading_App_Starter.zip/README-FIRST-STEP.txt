GV TRADING PLATFORM — APP STARTER

This is Step 1: a Progressive Web App (PWA) starter based on your existing index.html.
It keeps the existing site and adds install metadata, a GV icon, and a basic service worker.

NEXT:
1. Upload ALL four files together to the root of your existing GitHub Pages repository:
   index.html
   manifest.webmanifest
   service-worker.js
   gv-icon.svg
2. Commit to the branch/folder that currently publishes your website.
3. Open the deployed HTTPS website on your device.
   Android/desktop: use the browser's Install app / Install GV Trading option.
   iPhone: open in Safari, tap Share, then Add to Home Screen.

IMPORTANT:
- This is an installable web app starter, not yet a native APK/Play Store app.
- The service worker only caches the app shell; authenticated Supabase data and trading actions still need a live connection.
- Demo balances and trades must remain simulated until backend rules and tests are complete.
- Do not put Supabase service-role keys or administrator secrets in this HTML.
- The administrator-only Control Center must be enforced by server/database authorization, not merely hidden in the page.
- Keep a copy of your current working site before replacing it.
